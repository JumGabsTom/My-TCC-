<?php
try
{
	$host = "localhost"; 			
	$user = "id19256720_cem"; 
	$pass = "Bd970812rc@23"; 
	$banco = "id19256720_rc";
	$dns = "mysql:dbname=rc;host=localhost"; //Chat
	
		$pdo = new PDO($dns, $user, $pass); //Chat
		
	$conexao = @mysqli_connect($host, $user, $pass, $banco ) 
	or die ("Não foi possível acessar o banco de dados, por favor, tente novamente mais tarde");
	$conexao -> set_charset("utf8"); //Chat
}
catch (PDOException $e) //Chat
{
	echo "Erro: " . $e->getMessage();
}

?>