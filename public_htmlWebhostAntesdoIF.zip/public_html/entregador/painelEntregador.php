<?php

    include_once('../Vlogin.php');
    include_once('Vent.php');//Arquivo para verificar se é um entregador que está logado

        //Código para manipular link do botão de logoff
        $linkBtnLogin;
        
            $linkBtnLogin = '../login/logoff.php';
            //FIM do Código para manipular link do botão de logoff

            $nomeUsuarioLogado = $dadosLogin['nome'];
            $idUsuarioLogado = $dadosLogin['idUsuario'];

        ?>
        <html lang="pt-br">
            <head>
                <meta charset="UTF-8">
                <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
                <title>Painel do Entregador|RClothes</title>
            </head>
            <body>
                <h1>PAINEL DO ENTREGADOR</h1>
                (Mensagem de teste)
                <br>Você está logado como: <?php echo $dadosLogin['nome']; ?>
                <br>ID: <?php echo $dadosLogin['idUsuario']; ?>
                <input type="button" value="Fazer Logoff" onclick="location.href='<?php echo "$linkBtnLogin"; ?>'"><!--Botão de login/logoff-->

            </body> 
    </html>
        <?php

?>