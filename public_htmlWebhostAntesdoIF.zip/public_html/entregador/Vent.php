<?php //Esse arquivo tem a função de verificar se quem está logado é um Entregador
      //Vent = Verificação de entregador.

    include_once('../Vlogin.php');

    if ($logado == 0) //Não logado
    {
        header('Location: ../index.php');
    }

    else if ($dadosLogin['tipoConta'] != 2) //Está logado mas não é Entregador
    {
        header('Location: ../index.php');
    }
    else if ($dadosLogin['statusConta'] == 0)
    {
        die('Você não tem permissão para acessar essa págiana, primeiro <a href="../login/logoff.php">faça logoff</a>, depois faça login e valide sua conta');
    }
?>