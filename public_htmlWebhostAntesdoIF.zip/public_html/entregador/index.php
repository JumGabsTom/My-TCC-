<?php

header('Location: painelEntregador.php');

?>