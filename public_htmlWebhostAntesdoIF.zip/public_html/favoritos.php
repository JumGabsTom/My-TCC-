<?php
include_once('Vcli.php');
include_once('Header/header3.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
    <link rel="stylesheet" href="styles/favoritos.css" />
    <meta charset="UTF-8">
    <title>RClothes | Produto</title>
</head>

<?php include_once('styles/favoritos.css'); ?>

<body class="body">
    <?php
        if($logado) {
            $idUsuario = $dadosLogin["idUsuario"];
            $sqlFavoritos = 
            "SELECT p.idProduto, p.nome, p.preco, p.imagemUrl
            FROM `Produto` p
            INNER JOIN `Favorito` f ON f.idProduto = p.idProduto
            INNER JOIN `usuario` u ON f.idUsuario = u.idUsuario
            WHERE u.idUsuario = $idUsuario;";
            $resultadoFavoritos = mysqli_query($conexao, $sqlFavoritos);
    
            if(mysqli_num_rows($resultadoFavoritos) > 0) {
                ?>
                <div class="list-group">
                <?php
                while($row = mysqli_fetch_assoc($resultadoFavoritos)) {
                    $idProduto = $row["idProduto"];
                    $nome = $row["nome"];
                    $preco = $row["preco"];
                    $imagem = explode("\n", $row["imagemUrl"])[0];
                    
    $urlImagem;
    $PImagem; //PImagem = Primeira imagem
    if (empty($imagem))
    {
       $PImagem = "semImagens.png";
       $urlImagem = "imgs/";
    }
    else
    {
        $PImagem = $imagem;
        $urlImagem = "imgProdutos/";
    }
                    
                    ?>
                        <a href="produto.php?id=<?php echo md5($idProduto); ?>" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <img class="imgFavorito" src="<?php echo $urlImagem . $PImagem;?>"></img>
                            </div>
                            <p class="mb-1"><?php echo $nome; ?></p>
                            <small class="text-muted">R$ <?php echo number_format($preco,2,",","."); ?></small>
                        </a>
                    <?php
                }
                ?>
                </div>
                <?php
            }
            else {
                ?>
                <div class="status">Nada na lista de favoritos.</div>
            <?php }
        }
        else { ?>
                    <center>
        <h1>Você não está logado!</h1>
        <h2><a href="login/login.php">Faça login</a> para acessar a lista de favoritos!</h2>
        </center>
        <?php }
    ?>
    
    <?php include_once('footer/footer2.php'); ?>
</body>
</html>