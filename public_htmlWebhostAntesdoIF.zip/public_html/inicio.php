<?php

include_once('Vlogin.php');
include_once('Vcli.php'); //Arquivo para verificar se é um cliente que está logado

   //---------------Para criar variável $dadosProduto posteriomente---------------
    $PPNA = "";//PENA = Pesquisa de produto (produto não encontrado) - exibe mensagem de produto não encontrado.
    $txtPPNA = "O Produto pesquisado não foi encontrado!<br>Tente usar palavras diferentes ou alterar os filtros.";//$txtPPNA = Texto da variável $PPNA.
    $haFiltros = 0; //Para estilização do filtros (Front-end)
    if (!empty($_GET['PProduto'])) //Se um produto for pesquisado
    {
       $PProduto = $_GET['PProduto'];
       
       if ($_GET['VtJs'] == 8 && $_GET['VcJs'] == 3) //Não há filtros mas há pesquisa
       {
            $VtJs = $_GET['VtJs'];//Recuperar o tipo selecionado que está na URL
            $VcJs = $_GET['VcJs']; //Recuperar a categoria selecionada que está na URL
            $queryProduto = mysqli_query($conexao, "select * from Produto where nome like'%$PProduto%' and quantidadeEstoque > 0 or descricao like '%$PProduto%' and quantidadeEstoque > 0 order by idProduto");
        
		if (!$queryProduto)
		{
            $PProduto = $_GET['PProduto'];
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	        
		if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
		{
		    $PPNA = $txtPPNA;
		}
       }
        if (!empty($_GET['VtJs']) && $_GET['VtJs'] < 8 && !empty($_GET['VcJs']) && $_GET['VcJs'] < 3)//Filtro para VtJs e VcJs.
       {
           $haFiltros = 1;
            $VtJs = $_GET['VtJs'];//Recuperar o tipo selecionado que está na URL
            $VcJs = $_GET['VcJs']; //Recuperar a categoria selecionada que está na URL
            $queryProduto = mysqli_query($conexao, "select * from Produto where idTipo like $VtJs and idCategoria like $VcJs and nome like '%$PProduto%' and quantidadeEstoque > 0 or descricao like '%$PProduto%' and idTipo like $VtJs and idCategoria like $VcJs and quantidadeEstoque > 0 order by idProduto");
        
		if (!$queryProduto)
		{
            $PProduto = $_GET['PProduto'];
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	        
		if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
		{
		    $PPNA = $txtPPNA;
		}
       }//filtro VtJs e VcJs
       else if (!isset($_GET['VtJs']) or $_GET['VtJs'] == 8 && isset($_GET['VcJs']) && $_GET['VcJs'] <3) //Se o tipo não for filtrado e a categoria categoria for.
       {
           $haFiltros = 1;
           $VtJs = 8; //Valor do select "tipo" se houver pesquisa
           $VcJs = $_GET['VcJs']; //Valor do select categoria se houver pesquisa
        $queryProduto = mysqli_query($conexao,"select * from Produto where nome like '%$PProduto%' and idCategoria like $VcJs and quantidadeEstoque > 0 or descricao like '%$PProduto%' and idCategoria like $VcJs and quantidadeEstoque > 0 order by idProduto");
        $PProduto = $_GET['PProduto']; //Se houver produto digitado (Valor usado para preencher a caixa de pequisa de produto)

	if (!$queryProduto) {
	    $PProduto = $_GET['PProduto'];
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>');  
	}
	if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
	{
	    $PPNA = $txtPPNA;
	}
       }//If -empty($_GET['VtJs']) 
   // or !isset($_GET['VtJs']) && !isset($_GET['VcJs'])
   else if (!isset($_GET['VcJs']) or $_GET['VcJs'] = 3 && isset($_GET['VtJs']) && $_GET['VtJs'] < 8)//Se a categoria não for filtrada, mas o tipo for.
   {
       $haFiltros = 1;
       $VtJs = $_GET['VtJs'];
       $VcJs = 3;
        $queryProduto = mysqli_query($conexao,"select * from Produto where nome like '%$PProduto%' and idTipo like $VtJs and quantidadeEstoque > 0 or descricao like '%$PProduto%' and idTipo like $VtJs and quantidadeEstoque > 0 order by idProduto");
        $PProduto = $_GET['PProduto']; //Se houver produto digitado (Valor usado para preencher a caixa de pequisa de produto)

	if (!$queryProduto) {
	    $PProduto = $_GET['PProduto'];
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>');  
	}
	if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
	{
	    $PPNA = $txtPPNA;
	}
   } //Fim se a categoria não for filtrada, mas o tipo for.
   }//Fim se hover algo pesquisado 
   else if (isset($_GET['PProduto']))//Se um produto NÃO for pesquisado, mas houver filtros
   {
       $haFiltros = 1;
       $PProduto = "";
       
       if ($_GET['PProduto'] == "" && $_GET['VtJs'] == 8 && $_GET['VcJs'] == 3)//Se não houver pesquisa, nem filtros, mas houver valores neutros na URL
       {
           header('Location: inicio.php');
       }
       
       else if (!empty($_GET['VtJs']) && $_GET['VtJs'] != "8" && !empty($_GET['VcJs']) && $_GET['VcJs'] < "3")//Filtro para VtJs e VcJs.
       {
            $VtJs = $_GET['VtJs'];//Recuperar o tipo selecionado que está na URL
            $VcJs = $_GET['VcJs']; //Recuperar a categoria selecionada que está na URL
            $queryProduto = mysqli_query($conexao, "select * from Produto where idTipo like $VtJs and idCategoria like $VcJs and quantidadeEstoque > 0 order by idProduto");
        
		if (!$queryProduto)
		{
            $PProduto = "";
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	        
		if (mysqli_num_rows($queryProduto) < 1)//Produto não encontrado
		{
		    $PPNA = $txtPPNA;
		}
       }//filtro VtJs e VcJs
       else if (!isset($_GET['VtJs']) or $_GET['VtJs'] == 8 && isset($_GET['VcJs']) && $_GET['VcJs'] <3) //Se o tipo não for filtrado, mas a categoria for.
       {
           $VtJs = 8; //Valor do select tipo se não houver pesquisa
           $VcJs = $_GET['VcJs']; //Valor do select categoria se não houver pesquisa
        $queryProduto = mysqli_query($conexao,"select * from Produto where idCategoria like $VcJs and quantidadeEstoque > 0 order by idProduto");
        $PProduto = ""; //Se não houver produto digitado (Valor usado para preencher a caixa de pequisa de produto)

	if (!$queryProduto) {
	    $PProduto = "";
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>');  
	}
	if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
	{
	    $PPNA = $txtPPNA;
	}
       }//If -empty($_GET['VtJs']) 
   // or !isset($_GET['VtJs']) && !isset($_GET['VcJs'])
   else if (!isset($_GET['VcJs']) or $_GET['VcJs'] = 3 && isset($_GET['VtJs']) && $_GET['VtJs'] < 8)//Se a categoria não for filtrada, mas o tipo for.
   {
       $VtJs = $_GET['VtJs'];
       $VcJs = 3;
        $queryProduto = mysqli_query($conexao,"select * from Produto where idTipo like $VtJs and quantidadeEstoque > 0 order by idProduto");
        $PProduto = ""; //Se não houver produto digitado (Valor usado para preencher a caixa de pequisa de produto)

	if (!$queryProduto) {
	    $PProduto = "";
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>');  
	}
	if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
	{
	    $PPNA = $txtPPNA;
	}
   } //Fim se a categoria não for filtrada, mas o tipo for.
   }//Else if - fim Se um produto NÃO for pesquisado
   
    else if (!isset($_GET['PProduto']) && !isset($_GET['VcJs']) && !isset($_GET['VtJs']))//Não há pesquisa nem filtros nem nada na URL
   {
       $VtJs = 8;
       $VcJs = 3;
        $queryProduto = mysqli_query($conexao,"select * from Produto where quantidadeEstoque > 0 order by idProduto");
        $PProduto = ""; //Se não houver produto digitado (Valor usado para preencher a caixa de pequisa de produto)

	if (!$queryProduto) {
	    $PProduto = "";
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>');  
	}
	if (mysqli_num_rows($queryProduto) < 1)//Produto pesquisado não encontrado
	{
	    $PPNA = $txtPPNA;
	}
   }
	   //---------------Fim de "para criar variável $dadosProduto posteriomente"--------------- 
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
        <meta charset="UTF-8">
        <title>RClothes | Início</title>
        <meta name="viewport" content="width=device-width">
    </head>
            <?php include_once('styles/inicio.css'); ?>
    <body class="body">
        
        <?php include_once('Header/header3.php');?>
        
            <link href="styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
        <center><table><tr><td><center> <div class="divPes input-group mb-3">
  <button class="btn btn-trasnparency" type="button" id="idBtnPesquisar" onclick="PProdutoJs()"><?php include_once('icones/search.svg');?></button><input type="text" id="pesquisarProduto" value="<?php echo $PProduto; ?>" placeholder="O que deseja?"/></div></center></td><td><?php
        //script para o botão filtros
        
        $haFiltrosTxt;
        if ($haFiltros == 1)
        {
            $haFiltrosTxt = "sim";
        }
        else
        {
            $haFiltrosTxt = "não";
        }
        
        ?>
        
      <div class="divfiltro dropdown">
 <button class="btn btn-transparecy dropdown-toggle" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
  <lable class="filtrosIcone"><?php if ($haFiltros == 1){include('icones/funnel_icon_125276.svg');}else{include_once('icones/funnel_icon_125276.svg');} ?></lable>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
      <center>Tipo:
    <li><select id="IdSelTipo">
    <option value="1">Camisas</option>
    <option value="2">Vestidos</option>
    <option value="3">Gravatas</option>
    <option value="4">Calças</option>
    <option value="5">Meias</option>
    <option value="6">Cintos</option>
    <option value="7">Ternos</option>
    <option value="8" selected>Todos</option>
    </li></select><br>
    Categoria:
    <li><select id="IdSelCategoria">
    <option value="1">Feminino</option>
    <option value="2">Masculino</option>
    <option value="3" selected>Todos</option>
    </select>
        </select></li></center>
        <center><input class="btnEnviar" type="button" value="Filtrar" onclick="PProdutoJs ()"><br>
        <input class="btnLimpar" type="button" value="Limpar" onclick="limparFiltros()"></center>

  </ul>
</div></td></td></table></center>
<div class="container">
    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
        <!-- Carousel indicators -->
        <ol class="carousel-indicators">
            <li data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
        </ol>
        
        <!-- Wrapper for carousel items -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="imgs/elsa.jpg" class="d-block w-100" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="imgs/enrolados.jpg" class="d-block w-100" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="imgs/cr7.jpg" class="d-block w-100" alt="Slide 3">
            </div>
        </div>

        <!-- Carousel controls -->
        <a class="carousel-control-prev" href="#myCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
</div>
    
    <style>
        /* GLOBAL STYLES
-------------------------------------------------- */
/* Padding below the footer and lighter body text */

body {
  padding-top: 3rem;
  padding-bottom: 3rem;
  color: #5a5a5a;
}


/* CUSTOMIZE THE CAROUSEL
-------------------------------------------------- */

/* Carousel base class */
.carousel {
  margin-bottom: 4rem;
}
/* Since positioning the image, we need to help out the caption */
.carousel-caption {
  bottom: 3rem;
  z-index: 10;
}

/* Declare heights because of positioning of img element */
.carousel-item {
  height: 32rem;
  background-color: #777;
}
.carousel-item > img {
  position: absolute;
  top: 0;
  left: 0;
  min-width: 100%;
  height: 32rem;
}


/* MARKETING CONTENT
-------------------------------------------------- */

/* Center align the text within the three columns below the carousel */
.marketing .col-lg-4 {
  margin-bottom: 1.5rem;
  text-align: center;
}
.marketing h2 {
  font-weight: 400;
}
.marketing .col-lg-4 p {
  margin-right: .75rem;
  margin-left: .75rem;
}


/* Featurettes
------------------------- */

.featurette-divider {
  margin: 5rem 0; /* Space out the Bootstrap <hr> more */
}

/* Thin out the marketing headings */
.featurette-heading {
  font-weight: 300;
  line-height: 1;
  letter-spacing: -.05rem;
}


/* RESPONSIVE CSS
-------------------------------------------------- */

@media (min-width: 40em) {
  /* Bump up size of carousel content */
  .carousel-caption p {
    margin-bottom: 1.25rem;
    font-size: 1.25rem;
    line-height: 1.4;
  }

  .featurette-heading {
    font-size: 50px;
  }
}

@media (min-width: 62em) {
  .featurette-heading {
    margin-top: 7rem;
  }
}
    </style>                      
    <!--//------------------------------------FIM CARROSEL------------------------------------\\-->
                      
        <!----------------------------Catálogo---------------------------->
                      
    <div class="container">
  <div class="row">
    <?php while($dadosProduto=mysqli_fetch_array($queryProduto)) {
    
    //Capturar a primeira imagem inserida do produto
    
   
    
    $PImagemArray =  $dadosProduto['imagemUrl'];//$PImagem = Primeira imagem (Array)
    $urlImagem;
    if (empty($PImagemArray[0]))
    {
       $PImagem = "semImagens.png";
       $urlImagem = "imgs/";
    }
    else
    {
        $PImagemArraylinha1 = explode("\n",$PImagemArray);
        $PImagem = $PImagemArraylinha1[0];
        $urlImagem = "imgProdutos/";
    }
    
    //Fim de capturar a primeira imagem inserida do produto
    
    ?> <!--Craindo a variável $dadosProduto-->
      <div class="col-6 col-sm-4 col-md-3 col-lg-2">
          
    <a class="linkCard" href="produto.php?id=<?php echo md5($dadosProduto["idProduto"]);?>" >
        
        <div class="card">
            
  <img src="<?php echo $urlImagem . $PImagem; ?>" class="img-fluid" alt="...">
  <div class="card-body">
    <h5 class="card-title"><?php echo $dadosProduto['nome']; ?></h5>
    <p class="card-text">R$ <?php echo number_format($dadosProduto['preco'],2,",","."); ?></p>
    <a href="produto.php?id=<?php echo md5($dadosProduto["idProduto"]);?>" class="btn btn-primary">Ver detalhes</a>
  </div>
</div>
        
        </div>
        </a>
        
        <?php } ?> <!--fim do while-->
        <?php echo $PPNA; 
        mysqli_close($conexao);
        ?>
        
        <!----------------------------Fim do catálogo---------------------------->
        </div>
        </div>
<?php include_once('footer/footer2.php'); ?>

            <script language="Javascript">
            
            //Completar select com valor
            var IdSelTipoJs = document.getElementById("IdSelTipo"); //IdSelTipoJs = IdSelTipo (Javascript)
            var VtJs2 = <?php echo $VtJs;?>;//php
            if (VtJs2 == "undefined")
            {
                VtJs2 = 8; //8 = Não especificado
            }
            var IdSelCategoriaJs = document.getElementById("IdSelCategoria"); //IdSelCategoriaJs = IdSelCategoria (Javascript)
            var VcJs2 = <?php echo $VcJs;?>;
            if (VcJs2 == "undefined")
            {
                VcJs2 = 3; //3 = Não especificado
            }
            
            IdSelTipoJs.value = (VtJs2);
            IdSelCategoriaJs.value = (VcJs2);
            //Fim completar select com valor
            
            function limpaPesquisa ()
            {
                var pesq = document.getElementById('pesquisarProduto');
                pesq.value = ("");
            }
            
            function PProdutoJs () //PEntregador = Pesquisar de Entregador (javaScript)
            {
                var VPProdutoJs = document.getElementById('pesquisarProduto').value; //VPProdutoJs = Variável Pesquisar de Produto (javaScript)
                var VtJs = document.getElementById('IdSelTipo').value;//VtJs = Variável filtro de tipo (javaScript)
                var VcJs = document.getElementById('IdSelCategoria').value;//VcJs = Variável filtro de Categoria (javaScript)
                window.location = "inicio.php?PProduto=" + VPProdutoJs + "&VtJs=" + VtJs + "&VcJs=" + VcJs;
            }
            function limparFiltros ()
            {
                window.location = "inicio.php";
            }
            
            //Ao teclar 'Enter' e a pesquisa produto estiver focada, buscar.
            var pce = document.getElementById('pesquisarProduto'); //pce = Pesquisa com enter.
            pce.addEventListener('focus', function()
            {
                document.addEventListener("keypress", function(e) {
            if(e.key === 'Enter')
            {
                PProdutoJs();
            }//if
            });//Função keypress
            });//pce (função)
            </script>
            
               