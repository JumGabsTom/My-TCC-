<?php
//Arquivo para somar uma quantidade escolhida pelo cliente a um itemProduto já existente

include_once('conexao.php');
include_once('Vcli.php');

$idUsuario = $dadosLogin['idUsuario'];
$idProdutoMD5 = $_GET['id'];
$quantidade = $_SESSION["qtdBDsomaItem"];

    $queryItemProduto = mysqli_query($conexao,"select pe.status, pr.quantidadeEstoque, pr.nome, ip.quantidade, ip.IdItemPedido, ip.idProduto from ItemPedido ip INNER JOIN Pedido pe ON ip.idPedidoFk = pe.idPedido INNER JOIN Produto pr ON ip.idProduto = pr.idProduto where pe.status = 0 and pe.idUsuario = $idUsuario and md5(ip.idProduto) = '$idProdutoMD5'");

    $dadosItemProduto=mysqli_fetch_array($queryItemProduto);
    
    if ($dadosItemProduto['quantidadeEstoque'] < $quantidade)
    {
        header('Location: produto.php?id=' . $idProdutoMD5);
    }

    if (!$queryItemProduto)
    {
        echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
        die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
    }
    
    $quantidadeTxt = "item";
        	    if ($quantidade > 1)
        	    {
        	        $quantidadeTxt = "itens";
        	    }
        	        $qtdAtual = $dadosItemProduto['quantidade'];
        	        $quantidadeTotal = $quantidade + $qtdAtual;
    
    //Botão "Sim" clicado:
    
    if (isset($_POST["btnSim"]))
{
    $idItemPedido = $dadosItemProduto['IdItemPedido'];
    
    if ($dadosItemProduto['quantidadeEstoque'] < $quantidade)
    {
        header('Location: produto.php?id=' . $idProdutoMD5 . "&msg=5"); //msg=5 = Produto não está em estoque.
    }
    else
    {
    
    $sqlupdateItemP =  "update ItemPedido set quantidade='$quantidadeTotal' where IdItemPedido=$idItemPedido";
	
	// executando instrução SQL
	$resultado = @mysqli_query($conexao, $sqlupdateItemP);
	if (!$resultado) {
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Query Inválida:</b>' . @mysqli_error($conexao)); 
	}
	else
	{
	    $_SESSION["qtdBDsomaItem"] = "n/a";
        header('Location: produto.php?id=' . $idProdutoMD5 . "&msg=4");
	}
	
	mysqli_close($conexao);
    }
}
    
    
?>
<html>
    <head>
        <title>Adicionar produtos</title>
    </head>
    
    <?php include_once('styles/BDsomaItemProduto.css'); ?>
    
    <body>
        
        <h2>O produto selecionado (<?php echo $dadosItemProduto['nome']; ?>) já está no seu pedido em aberto, deseja adicionar mais <?php echo $quantidade; ?> <?php echo $quantidadeTxt;?> deste mesmo produto ao pedido? A quantidade total será de <?php echo $quantidadeTotal; ?> ítens.
        	    <br>
        	    
        <form method="post">
            <input type="submit" value="Sim" name="btnSim">
        </form>
        <input type="button" value="Não" onclick="window.location='produto.php?id=<?php echo $idProdutoMD5; ?>'">
    </body>
</html>