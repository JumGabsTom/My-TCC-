<?php
include_once('conexao.php');
include_once('Vcli.php');

/*
Mensagen que podem ser retornadas desta página para o produto.php:
1 - Quando o usuário não seleciona nenhuma estrela (Erro)
2 - Quando a avaliação é cadastrada com sucesso (Sucesso)
*/

$idProdutoMd5 = $_GET['idProduto'];

if (!empty($_POST['estrelas']))
{
    $estrela = $_POST['estrelas'];
    $opiniao = $_POST['opiniao'];
    $idUsuario = $dadosLogin['idUsuario'];
    
    //"Descriptografar" id MD5
    $sql = "SELECT * FROM Produto WHERE MD5(idProduto) = '$idProdutoMd5'";
	$resultado = mysqli_query($conexao, $sql);
	$dadosProdutoAv = mysqli_fetch_array($resultado); //$dadosProdutoAv = $dadosLogin da avaliação.
	
	$idProduto = $dadosProdutoAv['idProduto'];
    
    //Inserir dados na tabela

$sqlinsert =  "insert into Avaliacao (nota, opiniao, idProduto, idUsuarioFk) values ('$estrela', '$opiniao', '$idProduto', '$idUsuario')";

$resultado = @mysqli_query($conexao, $sqlinsert);
if (!$resultado) {
echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar ao início"><br><br>';
die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>' . @mysqli_error($conexao)); 
}
else
{
    $ultimoidProduto = mysqli_insert_id($conexao);
    header ("Location: produto.php?id=$idProdutoMd5&msg=2");
}

mysqli_close($conexao);

//Fim inserir dados na tabela
}
else
{
    header ("Location: produto.php?id=$idProdutoMd5&msg=1");
}

?>