<styles>
body{

  font-family: 'calibri light', calibri, arial, sans-serif;
}
div.body-content{
  margin-bottom: 40px;
}

footer.fixar-rodape{
  border-top: 1px solid #333;
  bottom: 0;
  left: 0;
  height: 40px;
  position: fixed;
  width: 100%;
}
</styles>
<div class="container body-content">
    Conteúdo do corpo do documento!
</div>
<footer class="fixar-rodape">
    <p>&copy; Tudo o que quiser colocar aqui</p>
</footer>