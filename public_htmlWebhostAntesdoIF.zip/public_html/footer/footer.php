<link href="../styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet" fixed-down>
  <link href="../styles/footer.css" rel="stylesheet">
<br>
<footer class="bg-light text-center text-lg-start">
    <div id="tudo">
  
  <div id="topo"></div>
  
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="linha">
      <!--Grid column-->

        <p><center>
              E-mail de suporte: criacaoemanutencaoo@gmail.com
        </p>
        </center>
      <!--Grid column-->
      
      <!--Grid column-->
    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
       RClothes
  </div>
  <!-- Copyright -->
</footer>

</body>
    
    </html>