<?php
//Exibir detalhes do pedido
include_once('conexao.php');
include_once('Vcli.php');
include_once('Vlogin.php');
//Verificar se a encomenda pertence ao cliente logado

$idPedidoMd5 = $_GET['id'];

$queryPedido = mysqli_query($conexao, "select * from Pedido where md5(idPedido) = '$idPedidoMd5'");

$dadosPedido=mysqli_fetch_array($queryPedido);

if ($logado == 0)
{
    header('Location: ../lista.php');
    die();
}
else if ($dadosPedido['idUsuario'] != $dadosLogin['idUsuario'])
{
    header('Location: ../lista.php');
    die();
}

        $queryItemPedido = mysqli_query($conexao, "select ip.idPedidoFk, ip.IdItemPedido, ip.quantidade, ip.idProduto, pr.preco, pr.imagemUrl, pr.nome FROM ItemPedido ip INNER JOIN Produto pr ON ip.idProduto = pr.idProduto where md5(ip.idPedidoFk) = '$idPedidoMd5'");
        
        $resultado = @mysqli_query($conexao, $queryItemPedido);
    /*if (!$resultado)
    {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar ao início"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>' . @mysqli_error($conexao)); 
    }//if (!$resultado)*/
        
        
        
        $qtdItens = mysqli_num_rows($queryItemPedido);
        
        $iap = "item adiconado"; //iap = Itens adicionados plural (para deixar texto no plural caso haja mais de 1 item)
        
        if ($qtdItens > 1)
        {
           $iap = "itens adiconados"; 
        }

    //Definir Status do pedido
    
    $statusPedido;
    $iconePedido;
        
        if ($dadosPedido['status'] == 0)
        {
            $statusPedido = 'Pedido não enviado ao vendedor.';
            
           $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-plus-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM9 5.5V7h1.5a.5.5 0 0 1 0 1H9v1.5a.5.5 0 0 1-1 0V8H6.5a.5.5 0 0 1 0-1H8V5.5a.5.5 0 0 1 1 0z"/>
</svg>';

        }
        else if ($dadosPedido['status'] == 1)
        {
            $statusPedido = 'Pedido em análise, entre em contato com o vendedor para negociar o método de pagamento através do nosso <a href="">chat</a>.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-chat-dots-fill" viewBox="0 0 16 16">
  <path d="M16 8c0 3.866-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.584.296-1.925.864-4.181 1.234-.2.032-.352-.176-.273-.362.354-.836.674-1.95.77-2.966C.744 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7zM5 8a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm4 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 2)
        {
            $statusPedido = 'Aguardando entrega no endereço combinado via <a href="">chat</a>.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-truck" viewBox="0 0 16 16">
  <path d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5v-7zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456zM12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12v4zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 3)
        {
            $statusPedido = 'Seu pedido não foi aceito pelo vendedor, entre em contato pelo <a href=".">chat</a> abaixo.';
            
            $iconePedido = '<svg style="color: red;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-x-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7.354 5.646 8.5 6.793l1.146-1.147a.5.5 0 0 1 .708.708L9.207 7.5l1.147 1.146a.5.5 0 0 1-.708.708L8.5 8.207 7.354 9.354a.5.5 0 1 1-.708-.708L7.793 7.5 6.646 6.354a.5.5 0 1 1 .708-.708z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 4)
        {
            $statusPedido = 'Seu pedido já foi entregue.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-check-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-1.646-7.646-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L8 8.293l2.646-2.647a.5.5 0 0 1 .708.708z"/>
</svg>';
        }

?>

<?php include_once('Header/header3.php');?>

<html lang="pt-br">
    
    <head>
        
        <meta charset="UTF-8">
        <title>Detalhes do pedido</title>
        
        </head>
        <?php include_once('styles/detalhesPedido.css'); ?>
        <body>
        
        <h1>Detalhes do pedido:</h1>
        <br>
        <lable class="status"><?php echo $iconePedido; ?>Status: <?php echo $statusPedido; ?></lable>
        <lable class="dataStatus">Última alteração do Status: <?php echo (new DateTime($dadosPedido['dataPedido']))->format('d/m/Y H:i'); ?></lable>
        <br>
        <?php if ($dadosPedido['status'] == 0){?>
        <button>Enviar pedido ao vendedor</button>
        <?php } ?>
        <?php if ($dadosPedido['status'] > 0){?>
        <button>Conversar com o vendedor via chat</button>
        <?php } ?>
        
        <div class="ConteudoPedido">
        <lable class="TituloConteudo">Conteúdo do pedido:</lable>
        <br>
        <div class="itensPedidoFluido">
            <?php
            $arrPreco = []; //$arrPreco = Array preço
            $arrQtd = []; //$arrQtd = Array Quantidade
            
            while($dadosItemPedido=mysqli_fetch_array($queryItemPedido)) {
                
            array_push($arrPreco, $dadosItemPedido['preco']);    
            array_push($arrQtd, $dadosItemPedido['quantidade']);
            
        $idProdutoMd5 = md5($dadosItemPedido['idProduto']);
                
                    //Capturar a primeira imagem inserida do produto
    
                        
    
                        $PImagemArray = $dadosItemPedido['imagemUrl'];//$PImagem = Primeira imagem (Array)
                        $urlImagem;
                        if (empty($PImagemArray[0]))
                        {
                           $PImagem = "semImagens.png";
                           $urlImagem = "imgs/";
                        }
                        else
                        {
                            $PImagemArraylinha1 = explode("\n",$PImagemArray);
                            $PImagem = $PImagemArraylinha1[0];
                            $urlImagem = "imgProdutos/";
                        }
                        
                    //Fim de capturar a primeira imagem inserida do produto
                ?>
                
                <a href="produto.php?id=<?php echo $idProdutoMd5; ?>">
                <div class="itemPedido">
                    <div class="conteudoItemPedido">
                    <img src="<?php echo $urlImagem . $PImagem; ?>" class="imgImagemProduto" alt="Responsive image">
                    
                    <center>x<?php echo $dadosItemPedido['quantidade']; ?> <?php echo $dadosItemPedido['nome']; ?>
                    <br>
                    R$ <?php echo  number_format($dadosItemPedido['preco'],2,",",".");?>
                    <br>
                    <form method="post" action="BDexcluirItemLista.php?idItem=<?php echo md5($dadosItemPedido['IdItemPedido']) . "&idPedido=" . md5($dadosPedido['idPedido']); ?>">
                    <input type="submit" value="Remover">
                    </form>
                    </center>
                    </div> <!--conteudoItemPedido-->
                    </div> <!--Item pedido-->
                    </a>
        <?php }//while  ?>
        </div><!--itensPedidoFluido-->
        </div> <!--ConteudoPedido-->
        
        <?php
        /*$arrPreco = [];
        $arrQtd = [];*/
        $total = 0;
        for ($i=0; $i < $qtdItens; $i++)
        {
           $total =  $total + $arrPreco[$i] * $arrQtd[$i];
        }
        ?>
        
        <lable>Total: R$ <?php echo number_format($total,2,",","."); ?> </lable>
        
        <center><button class="btnVlogin" title="Voltar à lista" onclick="location.href='lista.php'"><?php include_once('icones/Arrow_return_left_grande.svg') ?></button></center>
        
        </body>
        
        </html>
        
<?php include_once('footer/footer2.php'); ?>