<?php

include_once('conexao.php');
include_once('Vcli.php');

if ($logado == 1)
{

       date_default_timezone_set('America/Sao_Paulo');
    
    //Dados para o insert
    $idUsuario = $dadosLogin['idUsuario'];
    $idProdutoMD5 = $_GET['idProduto'];
    $dataAtual = date('Y/m/d H:i:s');
    $quantidade = $_POST['slctQuantidadeLista'];
    $mensagem = "";
    $status; // 0 = carrinho não enviado, 1 = carrinho enviado, 2 = carrinho aceito, 3 = carrinho não aceito, 4 = já entregado.
    
    //Recuperar dados da URL (MD5)
    $queryProduto = mysqli_query($conexao, "select * from Produto where md5(idProduto) = '$idProdutoMD5'");
            
    if (!$queryProduto)
    {
        echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
        die('<b>Query Inválida:</b>');  
    }
    
    $dadosProduto = mysqli_fetch_array($queryProduto);
    
    if ($dadosProduto['quantidadeEstoque'] < $quantidade)
    {
        header('Location: produto.php?id=' . $idProdutoMD5 . '&msg=5'); //msg=5 = Produto não está em estoque.
        die("Ocorreu um erro inesperado");
    }
    
    //Fim de recuperar dados da URL (MD5)
    
    $idUsuarioMd5 = MD5($dadosLogin['idUsuario']);
    
    $idProduto = $dadosProduto['idProduto'];
    
    $queryPedido = mysqli_query($conexao, "select * from Pedido where md5(`idUsuario`) = '$idUsuarioMd5' and status = 0");
            
    if (!$queryPedido)
    {
        echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
        die('<b>Query Inválida:</b>');  
    }
    
    $dadosPedido=mysqli_fetch_array($queryPedido);
    	        
    if (mysqli_num_rows($queryPedido) < 1)//Não há nenhum carrinho em aberto
    {
        $status = 0; //0 = carrinho não enviado
        //Inserir dados na tabela Pedido
            
        $sqlinsert =  "insert into Pedido (idUsuario, dataPedido, mensagem, status) values ('$idUsuario', '$dataAtual', '$mensagem', '$status')";
                        
        $resultado = @mysqli_query($conexao, $sqlinsert);
    if (!$resultado)
    {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar ao início"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>' . @mysqli_error($conexao)); 
    }//if (!$resultado)
    
    $ultimoidPedido = mysqli_insert_id($conexao);
                
    //Inserir dados na tabela ItemPedido
    $sqlinsert =  "insert into ItemPedido (idPedidoFk, quantidade, idProduto) values ('$ultimoidPedido', '$quantidade', '$idProduto')";
                
    $resultado = @mysqli_query($conexao, $sqlinsert);
    if (!$resultado)
    {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar ao início"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>' . @mysqli_error($conexao)); 
    }//if (!$resultado)
                
    }//Não há carrinhos em aberto
    		
    else //O carrinho está em aberto - não foi enviado
    {
        $idPedido = $dadosPedido['idPedido'];
        
        //Verificar se o produto já está no carrinho
        
         $queryItemProduto = mysqli_query($conexao,"select pe.status, pr.nome, ip.quantidade, ip.IdItemPedido, ip.idProduto from ItemPedido ip INNER JOIN Pedido pe ON ip.idPedidoFk = pe.idPedido INNER JOIN Produto pr ON ip.idProduto = pr.idProduto where pe.status = 0 and pe.idUsuario = $idUsuario and md5(ip.idProduto) = '$idProdutoMD5'");

            $dadosItemProduto=mysqli_fetch_array($queryItemProduto);

        	if (!$queryItemProduto)
        	{
        		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
        		die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
        	}
        	if (mysqli_num_rows($queryItemProduto) > 0) //Se o produto já estiver no carrinho em aberto
        	{
        	   $_SESSION["qtdBDsomaItem"] = $quantidade;
        	   header('Location:  BDsomaItemProduto.php?id=' . $idProdutoMD5);
        	   die("Morri");
        	}
        	else //Se o produto não estiver no carrinho em aberto
        	{
            	$sqlinsert =  "insert into ItemPedido (idPedidoFk, quantidade, idProduto) values ('$idPedido', '$quantidade', '$idProduto')";
                    
                $resultado = @mysqli_query($conexao, $sqlinsert);
                if (!$resultado)
                {
                    echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar ao início"><br><br>';
                    die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>' . @mysqli_error($conexao)); 
                }//if (!$resultado)
        	}//Fim não tem o produto no carrinho aberto
	
	//Fim de verificar se o produto já está no carrinho
    }//carrinho em aberto
    header('Location: ../produto.php?id=' . $idProdutoMD5 . '&msg=4');
}
else // Logado = 0
{
    header('Location: inicio.php');
}

?>