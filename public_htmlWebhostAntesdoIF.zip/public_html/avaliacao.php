<!--Avaliação-->
<?php include_once('styles/avaliacao.css');?>

            <div class="avaliacao">
            <h2>Avaliações públicas</h2>
                
        <?php
        $eacl = 0; //$eacl = existe avaliação do cliente logado ($eacl = 0 = não)
        
        if ($logado == 1)
        {
            $idProduto = $id;
            $idUsuario = $dadosLogin['idUsuario'];
            //Verificar se o usuário já fez uma avaliação deste produto
            $sql = "SELECT * FROM Avaliacao WHERE idUsuarioFk = '$idUsuario' and md5(idProduto) = '$idProduto'";
        	$resultado = mysqli_query($conexao, $sql);
	        $dadosAvaliacao = mysqli_fetch_array($resultado);
        	if (mysqli_num_rows($resultado) > 0) //Se o usuário já tiver feito uma avaliação deste produto:
        	{
        	    $eacl = 1; //$eacl = existe avaliação do cliente logado ($eacl = 1 = sim)
        	    
        	    $_SESSION['avaliacaoExcluir'] = $dadosAvaliacao['idAvaliacao']; //Variável de sessão para excluir avaliação (Id Avaliação)
        	    $_SESSION['avaliacaoExcluirIdProduto'] = $id; //Variável de sessão para excluir avaliação (Id do produto)
        	    
        	    ?>
        	        <div class="minhaAvaliacao">
        	            <div class="cabecalhoMinhaAvaliacao">
        	    <h4>Sua avaliação <button class="btn btn-danger" title="Excluir avaliação" onclick="window.location='BDexcluirAvaliacao.php'"><?php include_once('icones/Trash3_fill.svg'); ?></button></h4>
        	    </div><!--cabecalhoMinhaAvaliacao-->
        	    <div class="qtdEstrelasIndividual">(<?php echo $dadosAvaliacao['nota']; ?> estrelas)</div><div class="opiniaoIndividual">"<?php echo $dadosAvaliacao['opiniao']; ?>"</div>
        	    <hr>
        	    </div><!--minhaAvaliacao-->
        	    <h5>Outras avaliações:</h5>
        	    <?php
        	    
        	}
        	else //Se o usuário NÃO tiver feito uma avaliação deste produto:
        	{
        	    $eacl = 0; //$eacl = existe avaliação do cliente logado ($eacl = 0 = não)
        	    ?>
        	    
        	    <h5>Adicionar uma avaliação pública: </h5>
        	    
        	    
    <form method="POST" action="BDavaliacao.php?idProduto=<?php echo $id; ?>" enctype="multipart/form-data">
        
        <input type="text" name="opiniao" placeholder="Escreva uma avaliação" required>
        <div class="estrelas">
            
            <input type="radio" class="vazioClass" id="vazio" name="estrelas" checked onclick="estrela ()" value="0">
            
            <input type="radio" class="estrela" id="estrelaUm" name="estrelas" onclick="estrela ()" value="1">
            <label for="estrelaUm"><img src="../imgs/estrelaNaoPreenchida.png" id="estrelaUmLabel" alt="..." class="img-thumbnail"></label>
            
            <input type="radio" class="estrela" id="estrelaDois" name="estrelas" onclick="estrela ()" value="2">
            <label for="estrelaDois"><img src="../imgs/estrelaNaoPreenchida.png" id="estrelaDoisLabel" alt="..." class="img-thumbnail"></label>
            
            <input type="radio" class="estrela" id="estrelaTres" name="estrelas" onclick="estrela ()" value="3">
            <label for="estrelaTres"><img src="../imgs/estrelaNaoPreenchida.png" id="estrelaTresLabel" alt="..." class="img-thumbnail"></label>
            
            <input type="radio" class="estrela" id="estrelaQuatro" name="estrelas" onclick="estrela ()" value="4">
            <label for="estrelaQuatro"><img src="../imgs/estrelaNaoPreenchida.png" id="estrelaQuatroLabel" alt="..." class="img-thumbnail"></label>
            
            <input type="radio" class="estrela" id="estrelaCinco" name="estrelas" onclick="estrela ()" value="5">
            <label for="estrelaCinco"><img src="../imgs/estrelaNaoPreenchida.png" id="estrelaCincoLabel" alt="..." class="img-thumbnail"></label>
            
        <input type="submit" value="Enviar">
        </div>
        </form>
        <?php } /*Não avaliação*/ }/*logado*/ else {echo '<a href="login/login.php">Faça login</a> para fazer uma avaliação.';} ?>

<?php //Todas as avaliações

        $sa = ""; //$sa = Sem avaliações
        if ($eacl == 0)
        {
        $saTxt = "Este produto ainda não possui avaliações."; // saTxt = Texto da variável $sa
        }
        if($eacl == 1)
        {
            $saTxt = "Este produto ainda não possui outras avaliações."; // saTxt = Texto da variável $sa
        }
        
    if ($logado == 1)//Exibir avaliações, menos as que o cliente logado fez
    {
        $idUsuarioLogado = $dadosLogin['idUsuario'];
        $queryAvaliacao = mysqli_query($conexao, "select a.idUsuarioFk, a.nota, a.opiniao, u.nome as 'nome', u.sobrenome as 'sobrenome' FROM Avaliacao a INNER JOIN usuario u ON a.idUsuarioFk = u.idUsuario where md5(a.idProduto) = '$id' and a.idUsuarioFk != '$idUsuarioLogado' order by idProduto");
        
		if (!$queryAvaliacao)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }
	        
		if (mysqli_num_rows($queryAvaliacao) < 1)//Sem avaliações
		{
		    $sa = $saTxt; //$sa = Sem avaliações
		}
    }
    if ($logado == 0) //Exibir todas as avaliações
    {
        $queryAvaliacao = mysqli_query($conexao, "select a.idUsuarioFk, a.nota, a.opiniao, u.nome as 'nome', u.sobrenome as 'sobrenome' FROM Avaliacao a INNER JOIN usuario u ON a.idUsuarioFk = u.idUsuario where md5(a.idProduto) = '$id' order by idProduto");
        
		if (!$queryAvaliacao)
		{
            $PProduto = $_GET['PProduto'];
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	        
		if (mysqli_num_rows($queryAvaliacao) < 1)//Produto pesquisado não encontrado
		{
		    $sa = $saTxt; //$sa = Sem avaliações
		}
    }
    
        echo '<div class="divBorda"></div>';
	        
	        
	        /*Calcular média de estrelas*/
	        
	        //Obter o número de avaliações feitas:
	        
	        $sqlMedia = mysqli_query($conexao, "SELECT * FROM Avaliacao WHERE md5(idProduto) = '$id'");
        
		if (!$sqlMedia)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	        
		if (mysqli_num_rows($sqlMedia) < 1)
		{
		    $sa = $saTxt; //$sa = Sem avaliações
		}
	        
	        $numAvaliacoes = mysqli_num_rows($sqlMedia);
	        
            //Obter a soma de todas as avaliações:
    $queryMedia = ("select sum(nota) as sum from `Avaliacao` where MD5(idProduto) = '$id'");
        
		if (!$queryMedia)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	    
	    $queryMedia_resultado = mysqli_query($conexao, $queryMedia);
	    
	    while ($dadosMedia = mysqli_fetch_assoc($queryMedia_resultado))
	    {
	        $mediaSum = $dadosMedia['sum'];
	    }
	    $txtOpiniao; //Para mudar a palavra "Opiniões" para opinião se $numAvaliacoes for == 1
	    if ($numAvaliacoes > 1)
	    {
	        $txtOpiniao = "opiniões";
	    }
	    if ($numAvaliacoes == 1)
	    {
	        $txtOpiniao = "opinião";
	    }
	    if ($numAvaliacoes > 0)
	    {
	         $media = $mediaSum / $numAvaliacoes;
	         echo "<h3>Média entre " . $numAvaliacoes . " " . $txtOpiniao . ": <div class='estrelaMedia'>" . number_format($media, 1, ',','. ') . " estrelas </div></h3>";
	    }

/*Fim de calcular média de estrelas*/
	        
		 while($dadosAvaliacao=mysqli_fetch_array($queryAvaliacao))
		 {
		     ?>
		     <div class="divBorda"></div>
		     <div class="estrelasTodas">(<?php echo $dadosAvaliacao['nota'];?> Estrelas)</div>
		     <div class="nomeTodas"><h5><?php echo $dadosAvaliacao['nome'] . " " . $dadosAvaliacao['sobrenome']; ?></h5></div>
		     <div class="opiniaoTodas">- "<?php echo $dadosAvaliacao['opiniao']; ?>"</div>
		     <div class="divBorda"></div>
		     <?php
		 }
		echo '<h1>' . $sa . '</h1>'; //sa = Sem avaliações

//Calcular média 

/*$queryMedia = mysqli_query($conexao, "select * from Avaliacao SUM(nota) as soma FROM  where MD5(idProduto) = '$id'");
        
		if (!$queryMedia)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }*/
?>


<?php

//Calcular porcentagem para a prograssBar

    //1 estrela
    $queryNavBarAvaliacoes1 = mysqli_query($conexao, "select * from Avaliacao where nota = '1' and MD5(idProduto) = '$id'");
        
		if (!$queryNavBarAvaliacoes1)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>');  
	    }
	    
	    $a1e = mysqli_num_rows($queryNavBarAvaliacoes1);// $a1e = Avaliações com 1 estrla
	    $por1e =  $a1e/1 * 100;//$por1e = Porcentagem 1 estrela
	    
	  //2 estrelas
	      $queryNavBarAvaliacoes2 = mysqli_query($conexao, "select * from Avaliacao where nota = '2' and MD5(idProduto) = '$id'");
        
		if (!$queryNavBarAvaliacoes2)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }
	    
	    $a2e = mysqli_num_rows($queryNavBarAvaliacoes2);// $a2e = Avaliações com 2 estrlas
	    $por2e =  $a2e/2 * 100;//$por1e = Porcentagem 2 estrelas
	  //3 estrelas
	      $queryNavBarAvaliacoes3 = mysqli_query($conexao, "select * from Avaliacao where nota = '3' and MD5(idProduto) = '$id'");
        
		if (!$queryNavBarAvaliacoes3)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }
	    
	    $a3e = mysqli_num_rows($queryNavBarAvaliacoes3);// $a3e = Avaliações com 3 estrlas
	    $por3e =  $a3e/3 * 100;//$por1e = Porcentagem 1 estrelas
	  //4 estrelas
	      $queryNavBarAvaliacoes4 = mysqli_query($conexao, "select * from Avaliacao where nota = '4' and MD5(idProduto) = '$id'");
        
		if (!$queryNavBarAvaliacoes4)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }
	    
	    $a4e = mysqli_num_rows($queryNavBarAvaliacoes4);// $a4e = Avaliações com 4 estrlas
	    $por4e =  $a4e/4 * 100;//$por4e = Porcentagem 4 estrelas
	  //5 estrelas
	      $queryNavBarAvaliacoes5 = mysqli_query($conexao, "select * from Avaliacao where nota = '5' and MD5(idProduto) = '$id'");
        
		if (!$queryNavBarAvaliacoes5)
		{
            echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
            die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	    }
	    
	    $a5e = mysqli_num_rows($queryNavBarAvaliacoes5);// $a5e = Avaliações com 5 estrlas
	    $por5e =  $a5e/4 * 100;//$por5e = Porcentagem 5 estrelas

?>

</div> <!--<div class="avaliacao">-->


<script language="javascript">

function estrela ()
{
    
    if (document.getElementById("estrelaUm").checked)
    {
        //Estrela preenchida:
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaPreenchida.png";
        //Estrela não preenchida:
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaNaoPreenchida.png"
    }
        else if (document.getElementById("estrelaDois").checked)
    {
        //Estrela preenchida:
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaPreenchida.png";
        //Estrela não preenchida:
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaNaoPreenchida.png"
    }
        else if (document.getElementById("estrelaTres").checked)
    {
        //Estrela preenchida:
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaPreenchida.png";
        //Estrela não preenchida:
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaNaoPreenchida.png";
    }
        else if (document.getElementById("estrelaQuatro").checked)
    {
        //Estrela preenchida:
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaPreenchida.png";
        //Estrela não preenchida:
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaNaoPreenchida.png";
    }
        else if (document.getElementById("estrelaCinco").checked)
    {
        //Estrela preenchida:
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaPreenchida.png";
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaPreenchida.png";
        
    }
    else //Nenhuma estrela selecionada
    {
        document.getElementById("estrelaUmLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaDoisLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaTresLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaQuatroLabel").src = "../imgs/estrelaNaoPreenchida.png";
        document.getElementById("estrelaCincoLabel").src = "../imgs/estrelaNaoPreenchida.png";
    }
}
</script>