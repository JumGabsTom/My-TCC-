<html lang="pt-br">
    <head>
        <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
         <link href="../styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include_once('../styles/verificaEmail.css'); ?>
        <meta charset="UTF-8">
    </head>
</html>

<?php

include_once('../conexao.php');

//Recuperando da URL
$id = $_GET['id'];
$v = $_GET['v'];
$email = $_GET['email'];

//Decodificando ID
if ($v == 1 & $email == 0)
{
    	// criando a linha de Update

    	$sqlupdate =  "update usuario set statusConta=1 where MD5(idUsuario) = '$id'";
	
	// executando instrução SQL
	$resultado = @mysqli_query($conexao, $sqlupdate);
	if (!$resultado) {
		echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
		die('<b>Houve um erro inesperado. Query Inválida:</b>' . @mysqli_error($conexao)); 
	} else {
	    
        echo ('<center><h1><br>Seu email foi validado com sucesso.</h1><br><h2>Obrigado por escolher a RClothes!<br><style>.entregador{background-color: red; color: #ffffff;}</style><br><div class="entregador">Se você for entregador, favor selecionar a opção "Esqueci a senha" para definir a sua senha de acesso!</div></h2><br><h3><a href="login.php">faça login</a></h3></center>');
	}
	mysqli_close($conexao);
}
if ($v == 0 & $id == 0)
{
	$sql = "SELECT * FROM usuario WHERE MD5(email) = '$email'";
	$resultado = mysqli_query($conexao, $sql);
	$dadosLoginVm = mysqli_fetch_array($resultado); //$dadosLoginVm = $dadosLogin da verificação de E-mail
	$emailUsuario = $dadosLoginVm['email'];
	$EmailUsuarioMD5 = md5($dadosLoginVm['email']);
	$idUsuarioMD5 = md5($dadosLoginVm['idUsuario']);

	$assuntoEmail = "RCLOTHES - Validação de conta";
    $link = "login/verificaEmail.php?v=1&email=0&id=" . $idUsuarioMD5; //v=1 = E-mail validado
    $mensagemEmail = "Você criou uma conta RCLOTHES. Para validar sua conta clique aqui: https://rclothescem.000webhostapp.com/" . $link . " Caso contrário, não será possível fazer login.";

	mail($emailUsuario, $assuntoEmail, $mensagemEmail);
echo '<center><h1 class="titulo">VERIFIQUE SEU EMAIL</h1><br><h2>Sua conta foi criada, porém prescisamos que você valide-a verificando a mensagem que foi enviada para o e-mail "' . $emailUsuario . '"<br><h3>Caso contrário, não será possível fazer login.<h3>Se você já validou, <a href="login.php">faça login</a><br>Não recebeu nenhum e-mail? Verifique a caixa de Spam ou reenvie o e-mail</h3></center>';
echo '<center>Para reenviar o e-mail <a href="verificaEmail.php?v=0&id=0&email=' . $EmailUsuarioMD5 . '">clique aqui</a> ou atualize a página.</center>';
}

?>