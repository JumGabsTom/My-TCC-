<?php $linkBtnVoltar = 'login.php'; ?>
<?php include_once('../styles/Esqueciasenha.css'); ?>
<html lang="pt-br">
    <head>
        <title>Recuperação de senha</title>
        <meta charset="UTF-8">
        <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Judson" />
    </head>
<meta name="viewport" content="width=device-width">
 <h1 class="titulo">RECUPERAÇÃO DE SENHA</h1>
<form method="post">
     <div class="divLogin">
    <label class="lblEmail">E-mail:<br></label><input class="txtEmail" type="text" name="email" id="Email"><br>
    <input class="btnEnviar" type="submit" name="reset" id="reset" value="Enviar"/>
    <input class="btnCancelar" type="button" value="Cancelar" onclick="location.href='<?php echo "$linkBtnVoltar"; ?>'">
    <br/>
    </div>
</form>

<?php

include('../conexao.php');
include('./gCrypt.php');

function requestEmail($conexao, $email)
{
	$sqlReset = "SELECT * FROM `reset` WHERE `email` = '$email' AND TIMESTAMPDIFF(MINUTE, data_reset, NOW()) < 15";
	$sqlDeleteReset = "DELETE FROM `reset` WHERE `email` = '$email'";
	$resultadoReset = mysqli_query($conexao, $sqlReset);

	if(mysqli_num_rows($resultadoReset) > 0) { return "Um pedido de recuperação de senha já foi enviado para este email. Tente novamente em alguns minutos."; }
	else {
		$sqlid = "SELECT `auto_increment` FROM INFORMATION_SCHEMA.TABLES WHERE table_name = 'reset';";

		$last = md5(mysqli_fetch_array(mysqli_query($conexao, $sqlid))[0]);

		$sqlinsert = "insert into `reset` (email, token) values ('".$_POST['email']."', '". $last ."')";

		mysqli_query($conexao, $sqlDeleteReset);
		mysqli_query($conexao, $sqlinsert);

		$msg = "Você solicitou uma recuperação de senha.\nClique no link para continuar: https://rclothescem.000webhostapp.com/login/novaSenha.php?token=" . encrypt($email) . $last . "\nCaso você não tenha solicitado uma recuperação, ignore este email.";

		$msg = wordwrap($msg, 70);

		mail($email, "Recuperação de senha", $msg);
	
		return "Um pedido de recuperação foi enviado para $email.";
	}
}

if(array_key_exists('reset',$_POST)){
	echo requestEmail($conexao, $_POST['email']);
}

?>