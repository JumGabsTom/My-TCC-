<?php
//Lista de Encomendas
include_once('conexao.php');
include_once('Vcli.php');
include_once('Vlogin.php');
include_once('Header/header3.php');

if ($logado == 1)
{
    $nadaLista; // Nada na lista de encomendas
    $idUsuario = $dadosLogin['idUsuario'];
    
    
    /* prof 1:
    
    SELECT pe.idPedido, 
                     pe.idUsuario, 
                     pe.dataPedido, 
                     pe.mensagem, 
                     pe.status,
                     ip.IdItemPedido,
                     ip.quantidade,                     
                     ip.IdItemPedido
             FROM `Pedido` pe INNER JOIN `ItemPedido` ip 
             ON ip.idPedidoFk  = pe.idPedido   
                 WHERE pe.idUsuario = 81 and idPedido = 12
    
    
    
    Prof 2:
    
    $sql =  " SELECT pe.idPedido, 
                     pe.idUsuario, 
                     pe.dataPedido, 
                     pe.mensagem, 
                     pe.status,
                     ip.IdItemPedido,
                     ip.quantidade
             FROM `Pedido` pe INNER JOIN `ItemPedido` ip 
             ON ip.idPedidoFk  = pe.idPedido   
                 WHERE pe.idUsuario = ". $idUsuario; */
    
    $queryPedido = mysqli_query($conexao, "select * from Pedido where idUsuario = $idUsuario order by idPedido");
    
    //$queryPedido = mysqli_query($conexao, $sql);
            
    //--------------------------
        
	if (!$queryPedido)
	{
        echo '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br>';
        die('<b>Query Inválida:</b>' . @mysqli_error($conexao));  
	}
	        
    if (mysqli_num_rows($queryPedido) < 1)//Não há nada na lista
	{
	    $nadaLista = 1;
	    $nadaListaTxt = "Você ainda não adicionou nada à esta lista";
	}
	else
	{
	    $nadaLista = 0;
	}
    
    ?>
<head>
    
    <title>Lista de encomendas</title>
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
    <link href="../styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
    
    </head>
    
    <?php include_once('styles/lista.css'); ?>

<body>
    
    <h1>Lista de encomendas</h1>
    <?php if ($nadaLista == 1){?>
    
    <h2><?php echo $nadaListaTxt; ?></h2>
    
    <?php }
    
    while($dadosPedido=mysqli_fetch_array($queryPedido))
    { 
        $idPedido = $dadosPedido['idPedido'];
        
        $queryItemPedido = mysqli_query($conexao, "select i.quantidade, i.idProduto, p.imagemUrl, p.nome FROM ItemPedido i INNER JOIN Produto p ON i.idProduto = p.idProduto where i.idPedidoFk = '$idPedido'");
        
        $qtdItens = mysqli_num_rows($queryItemPedido);
        
        $iap = "item adiconado"; //iap = Itens adicionados plural (para deixar texto no plural caso haja mais de 1 item)
        
        if ($qtdItens > 1)
        {
           $iap = "itens adiconados"; 
        }
        
        $statusPedido;
        $iconePedido;
        
        if ($dadosPedido['status'] == 0)
        {
            $statusPedido = 'Pedido não enviado ao vendedor.';
            
           $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-plus-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM9 5.5V7h1.5a.5.5 0 0 1 0 1H9v1.5a.5.5 0 0 1-1 0V8H6.5a.5.5 0 0 1 0-1H8V5.5a.5.5 0 0 1 1 0z"/>
</svg>';

        }
        else if ($dadosPedido['status'] == 1)
        {
            $statusPedido = 'Pedido em análise, entre em contato com o vendedor para negociar o método de pagamento através do nosso <a href="">chat</a>.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-chat-dots-fill" viewBox="0 0 16 16">
  <path d="M16 8c0 3.866-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.584.296-1.925.864-4.181 1.234-.2.032-.352-.176-.273-.362.354-.836.674-1.95.77-2.966C.744 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7zM5 8a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm4 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 2)
        {
            $statusPedido = 'Aguardando entrega no endereço combinado via <a href="">chat</a>.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-truck" viewBox="0 0 16 16">
  <path d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5v-7zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456zM12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12v4zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 3)
        {
            $statusPedido = 'Seu pedido não foi aceito pelo vendedor, entre em contato pelo <a href=".">chat</a> abaixo.';
            
            $iconePedido = '<svg style="color: red;" xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-x-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7.354 5.646 8.5 6.793l1.146-1.147a.5.5 0 0 1 .708.708L9.207 7.5l1.147 1.146a.5.5 0 0 1-.708.708L8.5 8.207 7.354 9.354a.5.5 0 1 1-.708-.708L7.793 7.5 6.646 6.354a.5.5 0 1 1 .708-.708z"/>
</svg>';
        }
        else if ($dadosPedido['status'] == 4)
        {
            $statusPedido = 'Seu pedido já foi entregue.';
            
            $iconePedido = '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart-check-fill" viewBox="0 0 16 16">
  <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-1.646-7.646-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L8 8.293l2.646-2.647a.5.5 0 0 1 .708.708z"/>
</svg>';
        }
        
        ?>
        
        <div class="encomeda">
            
            <lable class="tituloEncomenda">Pedido: <?php echo $qtdItens . " " . $iap; ?></lable><br>
            <lable class="status"><?php echo $iconePedido; ?> Status: <?php echo $statusPedido; ?></lable>
            <br>
            <div class="conteudoPedido">
                <lable class="TituloConteudo">Conteúdo:</lable>
                <div class="itensPedidoFluido">

                <?php while($dadosItemPedido=mysqli_fetch_array($queryItemPedido)) {
                    
                    $idProdutoMd5 = md5($dadosItemPedido['idProduto']);
                
                    //Capturar a primeira imagem inserida do produto
    
   
    
                        $PImagemArray =  $dadosItemPedido['imagemUrl'];//$PImagem = Primeira imagem (Array)
                        $urlImagem;
                        if (empty($PImagemArray[0]))
                        {
                           $PImagem = "semImagens.png";
                           $urlImagem = "imgs/";
                        }
                        else
                        {
                            $PImagemArraylinha1 = explode("\n",$PImagemArray);
                            $PImagem = $PImagemArraylinha1[0];
                            $urlImagem = "imgProdutos/";
                        }
                        
                    //Fim de capturar a primeira imagem inserida do produto
                ?>
                
                <a href="produto.php?id=<?php echo $idProdutoMd5; ?>">
                <div class="itemPedido">
                    <div class="conteudoItemPedido">
                    <img src="<?php echo $urlImagem . $PImagem; ?>" class="imgImagemProduto" alt="Responsive image">
                    
                    <center>x<?php echo $dadosItemPedido['quantidade']; ?> <?php echo $dadosItemPedido['nome']; ?>
                    </center></div> <!--conteudoItemPedido-->
                    </div> <!--Item pedido-->
                    </a>
                <?php } 
                $idPedidoMd5 = md5($dadosPedido['idPedido']);
                ?>

                </div> <!--itensPedidoFluido-->
            </div>
            <br>
            <lable class="dataStatus">Última alteração de Status: <?php echo (new DateTime($dadosPedido['dataPedido']))->format('d/m/Y H:i'); ?>
            <br>
            <button type="button" class="btn btn-success" onclick="location.href='detalhesPedido.php?id=<?php echo $idPedidoMd5; ?>'">Ver detalhes do pedido</button>
        </div>
        
        <?php }
        mysqli_close($conexao);
        ?>
        
        
        </body>
        
    <?php }
    if ($logado == 0)
    {
        ?>
        
        <center>
        <h1>Você não está logado!</h1>
        <h2><a href="login/login.php">Faça login</a> para acessar a lista de encomendas!</h2>
        </center>
        
        <?php } ?>

<?php include_once('footer/footer2.php'); ?>