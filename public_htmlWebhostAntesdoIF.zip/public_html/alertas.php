<?php
$sqlNotificacoes = "SELECT * FROM `Notificacao` ORDER BY `dataNotificacao` DESC";
$resultadoNotificacoes = mysqli_query($conexao, $sqlNotificacoes);
?>

<div class="modal fade" id="notificacoesModal" tabindex="-1" aria-labelledby="notificacoesLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="notificacoesLabel">Notificações</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php
        if(mysqli_num_rows($resultadoNotificacoes) == 0) {?>
          <div class="notificacao">
            <h5>Sem notificações.</h5>
          </div>
        <?php }
        while($row = mysqli_fetch_assoc($resultadoNotificacoes)) {?>
          <div class="notificacao">
            <div class="notificacao-main">
              <div class="notificacao-texto"><?php echo $row["textoNotificacao"]; ?></div>
              <div class="notificacao-data"><h6><?php echo date_format(date_create($row["dataNotificacao"]), "d/m/Y (H:i:s)"); ?></h6></div>
            </div>
            <div class="notificacao-footer">
              <?php if($logado == 1 && $dadosLogin['tipoConta'] == 1) { ?><button class="btn btn-danger" data-bs-target="#excluirNotificacaoModal" data-bs-toggle="modal" onclick="$('#excluirNotificacaoForm').attr('action', '../adm/BDexcluirNotificacao.php?idNotificacao=<?php echo md5($row['idNotificacao']); ?>'); $('#textoNotificacaoForm').text('<?php echo $row['textoNotificacao']; ?>');">Excluir</button> <?php } ?>
            </div>
          </div>
        <?php } ?>
      </div>
      <div class="modal-footer">
        <?php if($logado == 1 && $dadosLogin['tipoConta'] == 1) { ?> <button class="btn btn-primary" data-bs-target="#novaNotificacaoModal" data-bs-toggle="modal">Nova Notificação</button> <?php } ?>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="novaNotificacaoModal" tabindex="-1" aria-labelledby="novaNotificacaoLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="novaNotificacaoLabel">Nova Notificação</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="../adm/BDinserirNotificacao.php">
                <div class="modal-body">
                    <div class="form-group">
                        <label> Texto </labe>
                        <input class="form-control" type="text" name="texto" id="texto" placeholder="Texto da notificação"/>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit" name="novaNotificacao" id="novaNotificacao">Enviar</button>
                    <button class="btn btn-secondary" type="button" data-bs-target="#notificacoesModal" data-bs-toggle="modal">Voltar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="excluirNotificacaoModal" tabindex="-1" aria-labelledby="excluirNotificacaoLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="excluirNotificacaoLabel">Excluir Notificação</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" id="excluirNotificacaoForm">
                <div class="modal-body">
                    <h6 id="textoNotificacaoForm" class="notificacao">Notificacao</h6>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger" type="submit" name="novaNotificacao" id="novaNotificacao">Excluir</button>
                    <button class="btn btn-secondary" type="button" data-bs-target="#notificacoesModal" data-bs-toggle="modal">Voltar</button>
                </div>
            </form>
        </div>
    </div>
</div>