<?php

header('Location: painelControle.php');

?>