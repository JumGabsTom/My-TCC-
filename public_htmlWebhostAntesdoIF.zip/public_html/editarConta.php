<?php 
include_once("Vcli.php");

if(!$logado) header('Location: inicio.php');

if (!empty($_GET['erro'])) //Se um erro for encontrado
{
    $erro = $_GET['erro']; //erroo = Erro rettornado do arquivo "BDcadastroProduto.php"
    
    $erroMensagem = "";
    
    if ($erro == 1)
    {
        $erroMensagem = "As senhas não coincidem.";
    }
	echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divErro">- ' . $erroMensagem . '</div></div>';
}

function getUsuario($conexao, $id) {
    $sqlUsuario = "SELECT * FROM `usuario` WHERE md5(`idUsuario`) = '$id'";
    $resultadoUsuario = mysqli_fetch_assoc(mysqli_query($conexao, $sqlUsuario));

    $nome = $resultadoUsuario["nome"];
    $sobrenome = $resultadoUsuario["sobrenome"];
    $email = $resultadoUsuario["email"];
    $endereco = $resultadoUsuario["endereco"];
    $dataNascimento = $resultadoUsuario["dataNascimento"];
?>

<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
    <link href="/styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <?php include_once('styles/editarConta.css'); ?>
    <title>Editar Conta</title>
</head>
<body>
    <center><h1 class="titulo">Editar Conta</h1></center>
    <div class= "divEditarConta"
    <center><div name="Editar" class"divEditar">
<form method='post' action='/BDeditarConta.php' 
class='editEntregadorForm'>
<label class="lblNome">Nome: <br></label><input required class="txtNome" type='text' name='nome' id='nome' placeholder='Nome' value='<?php echo $nome;?>'/>
<label class="lblSobrenome">Sobrenome: <br></label><input required class="txtSobrenome" type='text' name='sobrenome' id='sobrenome' placeholder='Sobrenome' value='<?php echo $sobrenome;?>'/>
<label class="lblEmail">Email: <br></label><input required class="txtEmail" type='email' name='email' id='email' placeholder='Email' value='<?php echo $email;?>'/>
<label class="lblSenha">Senha da conta: <br></label><input class="txtSenha" type='password' name='senha' id='senha' placeholder='Senha'/>
<label class="lblConfirmarSenha">Confirme a senha: <br></label><input class="txtConfirmarSenha" type='password' name='confirmarSenha' id='confirmarSenha' placeholder='Confirmar Senha'/>
<label class="lblEndereco">Endereço: <br></label><input required class="txtEndereco" type='text' name='endereco' id='endereco' placeholder='Endereço' value='<?php echo $endereco;?>'/>
<label class="lbldata">Data de nascimento: <br></label><input required class="txtData" type='date' name='dataNascimento' id='dataNascimento' placeholder='Data de Nascimento' value='<?php echo $dataNascimento;?>'/>
<input type='hidden' name='id' id='id' value='<?php echo $id;?>'/>
</div></center>
    <center><input class="btnEnviar" type='submit' name='edit' id='edit' value='Enviar'/><br/></center>
</form>
        <center><button class="btnVoltar"  name="btnVoltar" onclick="location.href='inicio.php'"><?php include_once('icones/Arrow_return_left_grande.svg');?></button></center>
</body>

    <?php
    return;
}

getUsuario($conexao, md5($dadosLogin["idUsuario"]));

?>
