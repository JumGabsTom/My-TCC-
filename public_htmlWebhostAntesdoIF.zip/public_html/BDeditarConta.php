<?php
            
include_once('Vcli.php');

function updateConta($conexao, $id) {
    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $email = $_POST["email"];
    $senha = md5($_POST["senha"]);
    $confirmarSenha = md5($_POST["confirmarSenha"]);
    $endereco = $_POST["endereco"];
    $dataNascimento = $_POST["dataNascimento"];
    
    if($senha != $confirmarSenha) header("Location: editarConta.php?erro=1");

    $sqlConta = "UPDATE `usuario` SET `nome` = '$nome', `sobrenome` = '$sobrenome', `email` = '$email', ";
    if($senha != "") $sqlConta .= "`senha` = '$senha', ";
    $sqlConta .= "`endereco` = '$endereco', `dataNascimento` = '$dataNascimento' WHERE md5(`idUsuario`) = '$id'";
    if(mysqli_query($conexao, $sqlConta))
    {
        ?>
        <?php include_once('styles/BDeditarEntregador.css'); ?>
        <center><div class='divEditado'><label class='lblEditado' >Conta editada com Sucesso</label>
        <br>
        <input type='button' class='btnVoltar' text='Voltar' value='Finalizar' onclick="location.href='index.php'"></button></div></center>
        <?php
    }
    else return '<input type="button" onclick="window.location='."'index.php'".';" value="Voltar"><br><br><b>Query Inválida:</b>' . @mysqli_error($conexao);
}

if(array_key_exists('id', $_POST)) {
    echo updateConta($conexao, $_POST["id"]);
}
?>
