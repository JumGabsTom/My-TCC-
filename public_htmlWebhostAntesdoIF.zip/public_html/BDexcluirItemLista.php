<?php
//Arquivo para deletar itens da lista de encomendas
include_once('conexao.php');
include_once('Vcli.php');

$Md5IdItemPedido = $_GET['idItem'];
$Md5IdPedido = $_GET['idPedido'];

$queryPedido = mysqli_query($conexao, "select * from Pedido where md5(idPedido) = '$Md5IdPedido'");

$dadosPedido=mysqli_fetch_array($queryPedido);

if ($logado == 0)
{
    header('Location: ../lista.php');
    die();
}
else if ($dadosPedido['idUsuario'] != $dadosLogin['idUsuario'])
{
    header('Location: ../lista.php');
    die();
}

$sqldelete =  "delete from  ItemPedido where md5(IdItemPedido) = '$Md5IdItemPedido' ";

$resultado = @mysqli_query($conexao, $sqldelete);
	if (!$resultado) {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>');
	} else {
	    
	    //---Alterar o AUTO_INCREMENT---\\
	
        $sqlupdate =  "ALTER TABLE `ItemPedido` AUTO_INCREMENT = 1";
    
        $resultado = @mysqli_query($conexao, $sqlupdate);
        if (!$resultado)
        {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>'); 
        }
        //---Fim do alterar o AUTO_INCREMENT---\\
	    
		header('Location: detalhesPedido.php?id=' . $Md5IdPedido);
	} 
	mysqli_close($conexao);

?>