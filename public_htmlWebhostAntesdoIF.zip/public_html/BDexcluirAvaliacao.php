<?php
include_once('conexao.php');
include_once('Vcli.php');

/*

Mensagens que podem ser retornadas desta página para a página produto.php:

3 - Mensagem de sucesso (Avaliação excluida com sucesso)

*/

$idAvaliacao = $_SESSION['avaliacaoExcluir'];

$sqldelete =  "delete from  Avaliacao where idAvaliacao = '$idAvaliacao' ";

	$resultado = @mysqli_query($conexao, $sqldelete);
	if (!$resultado) {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>');
	} else {
	    
	    //---Alterar o AUTO_INCREMENT---\\
	
        $sqlupdate =  "ALTER TABLE `Avaliacao` AUTO_INCREMENT = 1";
    
        $resultado = @mysqli_query($conexao, $sqlupdate);
        if (!$resultado)
        {
        echo '<br><input type="button" onclick="window.location='."'../index.php'".';" value="Voltar"><br><br>';
        die('<style> .erro { background-color: red; color: #ffffff;}</style><div class="erro"><b>Query Inválida:</b><br>Ocorreu um erro inesperado.</div><br>'); 
        }
        //---Fim do alterar o AUTO_INCREMENT---\\
	    
		header('Location: produto.php?id=' . $_SESSION['avaliacaoExcluirIdProduto'] . '&msg=3');
	} 
	mysqli_close($conexao);


?>