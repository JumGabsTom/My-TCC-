<?php
include_once("Vcli.php");

function inserirFavorito($conexao, $idProduto, $idUsuario) {
    $sqlFavorito = "INSERT INTO `Favorito` (`idProduto`, `idUsuario`) VALUES ('$idProduto', '$idUsuario')";
    $resultadoFavorito = mysqli_query($conexao, $sqlFavorito);

    $idProduto = md5($idProduto);

    if($resultadoFavorito) return "<script>window.location='produto.php?id=$idProduto'</script>";
    else return "<script>window.location='produto.php?id=$idProduto&erro=5'</script>";
}

function excluirFavorito($conexao, $idProduto, $idUsuario) {
    $sqlFavorito = "DELETE FROM `Favorito` WHERE `idProduto` = '$idProduto' AND `idUsuario` = '$idUsuario'";
    $resultadoFavorito = mysqli_query($conexao, $sqlFavorito);

    $idProduto = md5($idProduto);

    if($resultadoFavorito) return "<script>window.location='produto.php?id=$idProduto'</script>";
    else return "<script>window.location='produto.php?id=$idProduto&erro=6'</script>";
}

if(!$logado) {
    if(array_key_exists("id", $_GET)) echo "<script>window.location='produto.php?id=" . $_GET["id"] . "&erro=4'</script>"; //header("Location: produto.php?id=" . $_GET["id"] . "&erro=4");
    else echo "<script>window.location='inicio.php'</script>";
}

if(array_key_exists("acao", $_POST)) {
    if($_POST["acao"] == 1) echo excluirFavorito($conexao, $_POST["produto"], $dadosLogin["idUsuario"]);
    else echo inserirFavorito($conexao, $_POST["produto"], $dadosLogin["idUsuario"]);
}

if(array_key_exists("id", $_GET)) echo "<script>window.location='produto.php?id=" . $_GET["id"] . "&erro=4'</script>";
else echo "<script>window.location='inicio.php'</script>";
?>