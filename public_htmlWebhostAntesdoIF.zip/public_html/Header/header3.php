<?php
include_once('Vlogin.php');
include_once('Vcli.php'); //Arquivo para verificar se é um cliente que está logado

//Código para manipular texto do botão de login/logoff
$linkBtnLogin;
//Para debug (Excluir depois)
//Fim do Para debug (Excluir depois)

if (!isset($_SESSION['logado']))//Não Logado
{
    $linkBtnLogin = 'login/login.php';
}
else //Logado
{
    $linkBtnLogin = 'login/logoff.php';
    $TextTitleBtnConta = "Conta RClothes\nLogado como: " . $dadosLogin['nome'] . "\nE-mail: " . $dadosLogin['email'];
    $linkBtnSair = 'login/logoff.php';
}
    //FIM do Código para quando usuário está logado
    
    include_once('styles/header3.css');
    
?>


    <meta charset="UTF-8">
    <script src="../styles/jquery-3.6.1.min.js"></script>
    <script src="../styles/bootstrap-5.2.2-dist/js/bootstrap.bundle.js"></script>
    <link href="../styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous" />
    <link href="../styles/header.css" rel="stylesheet">
    <meta charset="UTF-8">


   <header bottom-top>
  <div class="container-fluid" style="background-color: #394B51; styles="border: none;">
   <nav class="navbar navbar-expand-lg" style="background-color: #394B51;" styles="border: none;">
    <a class="navbar-brand" href="../inicio.php" style="animation-name: opacidadeAnimacao; animation-duration: 3s;"><img src="../imgs/LogoHeader2.png"></a>
    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown"  >
      <ul class="navbar-nav">
          <a type="button" class="nav-link text-light text-white" title="Notificações e novidades" data-bs-toggle="modal" data-bs-target="#notificacoesModal" ><?php include('icones/Bell_fill_grande.svg'); ?></a>
              <?php if ($logado == 0){?>
          <a type="button" class="nav-link text-light text-white" data-bs-toggle="modal" data-bs-target="#entrarModal" title="Você não está logado" onclick="location.href='<?php echo "$linkBtnLogin"; ?>'">Entrar <?php include('icones/Box_arrow_in_left.svg');?></a>
        <?php } if ($logado == 1) { ?>
              <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" title="<?php echo $TextTitleBtnConta; ?>" href="#" id="navbarDropdown" role="button text-white" data-bs-toggle="dropdown" aria-expanded="false">
            Conta
          </a>
          <ul class="dropdown-menu text-black" aria-labelledby="navbarDropdown">
              <?php echo "<center>"; include('icones/People_circle.svg'); echo " <b>" . $dadosLogin['nome'] . " " . $dadosLogin['sobrenome'] . "</b><br>" . $dadosLogin['email'] . "</center>"; ?>
              <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="editarConta.php">Editar conta</a></li>
            <li><a class="dropdown-item" href="<?php echo $linkBtnSair; ?>">Sair</a></li>
          </ul>
        </li>
        <?php } ?>
      </ul>
    </div>
  </div>
                      </ul></div>
   </ul>
  </div>
</nav>
</header>
   <header top-center>
<div class="container-fluid" style="animation-name: fundoHeaderAnimacao; animation-duration: 1s;background-color: #CFC1A3; styles="border: none;">
   <div class="container-fluid" style="animation-name: fundoHeaderAnimacao; animation-duration: 1s; background-color: #CFC1A3; styles="border: none;">
          <nav class="navbar navbar-expand-lg" style=" animation-name: fundoHeaderAnimacao; animation-duration: 1s; background-color: #CFC1A3;">
          <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                                 <ul class="navbar-nav">
                                <a type="#" class="nav-link"">ㅤㅤㅤㅤㅤㅤㅤ</a>
                      </ul></div>
          <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
          <a type="button" class="nav-link" href="../inicio.php">Inicío <?php include_once('icones/House_door_fill.svg'); ?></a>
          <ul/>
          </div>
          <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
               <ul class="navbar-nav">
                      <a type="button" class="nav-link" href="../favoritos.php">Favoritos <?php include_once('icones/Star_fill.svg'); ?></a>
                      </ul></div>
                         <div class="collapse navbar-collapse" id="navbarNavDarkDropdown" "text-aling">
                                 <ul class="navbar-nav">
                                <a type="button" class="nav-link" href="../lista.php">Lista de encomendas <?php include_once('icones/Cart_fill.svg'); ?></a>
                      </ul></div>
            
          </nav>
  </div>
  </div>
 </header>
<?php include_once(__DIR__ . '/../' . "/alertas.php"); ?>