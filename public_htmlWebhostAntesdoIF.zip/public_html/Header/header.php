<?php
include_once('Vlogin.php');
include_once('Vcli.php'); //Arquivo para verificar se é um cliente que está logado

//Código para manipular texto do botão de login/logoff
$linkBtnLogin;
//Para debug (Excluir depois)
//Fim do Para debug (Excluir depois)

if (!isset($_SESSION['logado']))//Não Logado
{
    $linkBtnLogin = 'login/login.php';
}
else //Logado
{
    $linkBtnLogin = 'login/logoff.php';
    $TextTitleBtnConta = "Conta RClothes\nLogado como: " . $dadosLogin['nome'] . "\nE-mail: " . $dadosLogin['email'];
    $linkBtnSair = 'login/logoff.php';
}
    //FIM do Código para quando usuário está logado
?>

<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
    <script src="../styles/jquery-3.6.1.min.js"></script>
    <script src="../styles/bootstrap-5.2.2-dist/js/bootstrap.bundle.js"></script>
    <link href="../styles/bootstrap-5.2.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous" />
    <link href="../styles/header.css" rel="stylesheet">
    <meta charset="UTF-8">
  
    <meta name="viewport" content="width=device-width">
</head>

   <header>
<nav class="navbar navbar-expand-lg fixed-top>
        <a href="#" class="nav-brand">
        <a class="navbar-brand" href="../inicio.php"><img src="../imgs/LogoHeader2.png"></a>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target-"navbar-links" aria-controls="nav-links" aria-expanded="false" aria-label="toggle-navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
         <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
 <a type="button" class="nav-link" title="Notificações e novidades" data-bs-toggle="modal" data-bs-target="#notificacoesModal";><?php include('icones/Bell_fill_grande.svg'); ?></a>
       
        <?php if ($logado == 0){?>
         <li class="nav-login">
          <a type="button" class="nav-link" data-bs-toggle="modal" data-bs-target="#entrarModal" title="Você não está logado" onclick="location.href='<?php echo "$linkBtnLogin"; ?>'">Entrar<?php include('icones/Box_arrow_in_left.svg');?></a>
        </li>
        <?php } if ($logado == 1) { ?>
              <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" title="<?php echo $TextTitleBtnConta; ?>" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Conta
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <?php echo "<center>"; include('icones/People_circle.svg'); echo " <b>" . $dadosLogin['nome'] . " " . $dadosLogin['sobrenome'] . "</b><br>" . $dadosLogin['email'] . "</center>"; ?>
              <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Editar conta</a></li>
            <li><a class="dropdown-item" href="<?php echo $linkBtnSair; ?>">Sair</a></li>
          </ul>
        </li>
        <?php } ?>
      </ul>
    </div>
  </div>
</nav>
</header>

<?php include_once(__DIR__ . '/../' . "/alertas.php"); ?>