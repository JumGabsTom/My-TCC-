<?php 
include_once('Vlogin.php');
include_once('Vcli.php');
include_once('Header/header3.php');

/*

Mensagens recebidas de outras páginas para esta:
1 - Quando o usuário não seleciona nenhuma estrela (Erro)
2 - Quando a avaliação é cadastrada com sucesso (Sucesso)
3 - Quando a avaliação é excluída com sucesso (Sucesso)
4 - Quando o produto é adicionado à lista com sucesso (Sucesso)
5 - Quando o produto não está mais em estoque (Erro)
*/

if (isset($_GET['msg']))
{
    if ($_GET['msg'] == 5)
    {
        echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divMsg">- A quantidade selecionada do produto não está mais em estoque. Pedimos disculpas pela inconveniência.</div></div>';
    }
    if ($_GET['msg'] == 4)
    {
        echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divMsg">- Produto adicionado ao carrinho</div></div>';
    }
    else if ($_GET['msg'] == 3)
    {
        echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divMsg">- Avaliação excluída com sucesso!</div></div>';
    }
    else if ($_GET['msg'] == 2)
    {
        echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divMsg">- Avaliação cadastrada com sucesso!</div></div>';
    }
    else if ($_GET['msg'] == 1)
    {
        echo '<div class="shadow p-3 mb-5 bg-body rounded"><div class="divMsg">- Selecione ao menos uma estrela antes de fazer uma avaliação!</div></div>';
    }
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="shortcut icon" href="../imgs/RCLogo2.png" />
    <?php include_once('styles/produto.css'); ?>
    <meta charset="UTF-8">
    <title>RClothes | Produto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="body">

<?php
if(array_key_exists("id", $_GET)) {
    $id = $_GET["id"];
    $sqlProduto = 
    "SELECT p.idProduto, p.nome, p.descricao, p.preco, a.nome as 'categoria', 
    p.quantidadeEstoque, p.faixaEtaria, c.corNome as 'cor', 
    t.tipoNome as 'tipo', p.tamanho, p.imagemUrl
    FROM Produto p
    INNER JOIN Categoria a
    ON p.idCategoria = a.idCategoria
    INNER JOIN Cor c
    ON p.idCor = c.idCor
    INNER JOIN Tipo t
    ON p.idTipo = t.idTipo WHERE md5(`idProduto`) = '$id'";
    $resultadoProduto  = mysqli_query($conexao, $sqlProduto);
    if(mysqli_num_rows($resultadoProduto) > 0) {
        $row = mysqli_fetch_assoc($resultadoProduto);
        $idProduto = $row["idProduto"];
        $nome = $row["nome"];
        $descricao = $row["descricao"];
        $preco = $row["preco"];
        $categoria = $row["categoria"];
        $quantidade = $row["quantidadeEstoque"];
        $faixaEtaria = $row["faixaEtaria"];
        $cor = $row["cor"];
        $tipo = $row["tipo"];
        $tamanhoP = $row["tamanho"];
        
        //die($row["tipo"]);
        switch($tamanhoP) {
            case 1: $tamanho = "P"; break;
            case 2: $tamanho = "M"; break;
            case 3: $tamanho = "G"; break;
            case 4: $tamanho = "GG"; break;
            case 5: $tamanho = "Não especificado"; break;
        }
        $imagem = explode("\n", $row["imagemUrl"]);
        ?>
        <table>
  <tr>
    <td><?php } ?>
            <div id="carouselRoupa" class="carousel carousel-dark slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                  <div class="carousel-item active">
                      <img src="imgProdutos/<?php echo $imagem[0]; ?>" class="d-block w-100" alt="...">
                    </div>
                <?php for($i = 1; $i < sizeof($imagem); $i++)
                { 
                
                ?>
                    <div class="carousel-item">
                      <img src="imgProdutos/<?php echo $imagem[$i]; ?>" class="d-block w-100" alt="...">
                    </div>
                <?php } ?>
              </div>
              <?php if(sizeof($imagem) > 1) { ?>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselRoupa" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselRoupa" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
              <?php } ?>
            </div>
            
        </div></td>
    
    <td>    <h6 class="lblNome"> <?php echo $nome; ?></h6>
            <h6 class="lbldescricao"> <?php echo $descricao; ?></h6>
    
            
            <h6 class="lblCat">Categoria: <?php echo $categoria; ?></h6>
            <h6 class="lblQtd">Quantidade em estoque: <?php echo $quantidade; ?></h6>
            <?php if($faixaEtaria != "ne") { ?><h6 class="lblFaixa">Faixa Etária: <?php echo $faixaEtaria; ?></h6> <?php } ?>
            <h6 class="lblCor">Cor: <?php echo $cor; ?></h6>
            <h6 class="lblTipo">Tipo: <?php echo $tipo; ?></h6>
            <?php if($tamanhoP != 5) { ?><h6 class="lblTam">Tamanho: <?php echo $tamanho; ?></h6>
            <h6 class="lblPreço">R$ <?php echo number_format($preco,2,",","."); ?></h6>
            <?php if ($logado == 1) { ?>
            <div class="encomendar">
                <input type="submit" class="btnAddEncomenda" value="Encomendar agora">
                
        
<form method="POST" action="BDaddCarrinho.php?idProduto=<?php echo $id;?>">
    <input type="submit" class="btnAddLista" value="Adicionar à Lista">
    <lable for="slctQuantidadeLista" class="lblSlctQuantidadeLista">Quantidade: </lable>
<select class="slctQuantidadeLista" id="slctQuantidadeLista" name="slctQuantidadeLista">
    <?php 
    for ($i=0; $i < $row["quantidadeEstoque"]; $i++)
    {
        $imu = $i+1; //$imu = $i mais 1
    echo "<option value='" . $imu . "'>" . $imu . "</option>";
    }
?>
    </select>

</form>
<?php } ?>

<?php if($logado) {
$idUsuario = $dadosLogin["idUsuario"];
$sqlFavorito = "SELECT * FROM `Favorito` WHERE md5(`idProduto`) = '$id' AND `idUsuario` = '$idUsuario'";
$resultadoFavorito  = mysqli_query($conexao, $sqlFavorito);
if(mysqli_num_rows($resultadoFavorito) > 0) $acao = 1;
else $acao = 0;
if($acao) $heart = "icones/heart-fill.svg";
else $heart = "icones/heart.svg";
?>
<form method="POST" action="BDfavoritar.php?id=<?php echo $id;?>">
    <input type='hidden' name='produto' id='produto' value='<?php echo $idProduto;?>'/>
    <input type='hidden' name='acao' id='acao' value='<?php echo $acao;?>'/>
    <button type="submit" class="btn">
        <?php include($heart); ?>
    </button>
</form>
<?php } ?>
</div></td> 
            
  </tr>
 
</table>
    <?php }
    else { ?>
        <div>
            Produto inválido
        </div>
    <?php } 
}
else { ?>
    <div>
        Produto inválido
    </div>
<?php } ?>
<!--Form adicionar ao carrinho-->
<?php
if ($logado == 0)
{
    ?>
    
    <div class="facaLoginProduto"><h3><a href="login/login.php">Faça login</a> para negociar com o vendedor</h3></div>
    
    <?php
}
else
{
    ?>
    <!--ComponentesEncomendar-->
<?php } ?>

<?php include_once ('avaliacao.php'); ?>

</body>
</html>
<?php include_once('footer/footer2.php'); ?>